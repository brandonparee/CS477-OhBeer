if (Meteor.isCordova){

  Template.indexMobile.onCreated( () => {
    
  });

}
