if (Meteor.isCordova){

Modules.client = {};

}
