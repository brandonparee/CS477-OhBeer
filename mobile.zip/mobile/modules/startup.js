if (Meteor.isCordova){

let startup = () => {};

Modules.client.startup = startup;

}
